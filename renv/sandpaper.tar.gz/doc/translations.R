## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----echo = FALSE, results = "asis"-------------------------------------------
writeLines(paste("-", sandpaper::known_languages()))

## ----gettext------------------------------------------------------------------
library("withr")
library("sandpaper")
known_languages()
with_language("ja", {
  enc2utf8(gettext("Page not found", domain = "R-sandpaper"))
})
with_language("en", {
  enc2utf8(gettext("Page not found", domain = "R-sandpaper"))
})

## ----gettext-2----------------------------------------------------------------
with_language("xx", {
  enc2utf8(gettext("Page not found", domain = "R-sandpaper"))
})

## ----default-string-----------------------------------------------------------
with_language("ja", {
  enc2utf8(gettext("A new translation approaches!", domain = "R-sandpaper"))
})

## ----translation-list, results = "asis", echo = FALSE-------------------------
snd <- asNamespace("sandpaper")
res <- glue::glue("| `translate.{names(tr)}` | `{sQuote(tr, q = 2)}` |", 
  tr = snd$tr_src("varnish"))
writeLines(c("| variable | string |\n| --- | --- |", res))

## ----translation-list-computed, results = "asis", echo = FALSE----------------
snd <- asNamespace("sandpaper")
res <- glue::glue("| `{names(tr)}` | `{sQuote(tr, q = 2)}` |", 
  tr = snd$tr_src("computed"))
writeLines(c("| variable | string |\n| --- | --- |", res))

