## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
    collapse = TRUE,
    comment = "##"
)

## ----varnish-template-layout, echo = FALSE, results = "asis"------------------
writeLines("```html")
tplt <- system.file("pkgdown", "templates", "layout.html", package = "varnish")
writeLines(readLines(tplt))
writeLines("```")

## ----varnish-template-head, echo = FALSE, results = "asis"--------------------
writeLines("```html")
tplt <- system.file("pkgdown", "templates", "head.html", package = "varnish")
writeLines(readLines(tplt))
writeLines("```")

## ----list-store---------------------------------------------------------------
snd <- asNamespace("sandpaper")
this_list <- snd$.list_store()
names(this_list)
class(this_list)

# to set a list, use a NULL key
this_list$set(key = NULL, list(
  A = list(first = 1),
  B = list(
    C = list(
      D = letters[1:4],
      E = sqrt(2),
      F = TRUE
    ),
    G = head(sleep)
  )
))

# get the list
this_list$get()

# copy a list so that you can preserve the original list
that_list <- this_list$copy()

# update list elements by adding to them (note: vectors will be replaced)
that_list$update(list(A = list(platform = "MY COMPUTER")))
that_list$get()

# set nested list elements
that_list$set(c("A", "platform"), "YOUR COMPUTER")

# note that modified copies do not modify the originals
that_list$get()[["A"]]
this_list$get()[["A"]]

## ----lesson-store-------------------------------------------------------------
snd <- asNamespace("sandpaper")
some_lesson <- snd$.lesson_store()
names(some_lesson)

## ----create-namespace-example, message = FALSE--------------------------------
library("sandpaper")
snd <- asNamespace("sandpaper")

## ----create-example, message = FALSE------------------------------------------
# create a new lesson
lsn <- create_lesson(tempfile(), name = "An Example Lesson",
  rstudio = TRUE, open = FALSE, rmd = FALSE)
# add a new episode
create_episode_md(title = "First Example", add = TRUE, path = lsn, open = FALSE)

## ----globals-empty------------------------------------------------------------
snd <- asNamespace("sandpaper")
class(snd$.store)
print(snd$.store$get())
class(snd$this_metadata)
snd$this_metadata$get()
class(snd$.resources)
snd$.resources$get()
class(snd$instructor_globals)
snd$instructor_globals$get()
class(snd$learner_globals)
snd$learner_globals$get()

## ----validate-----------------------------------------------------------------
# first run is always longer than the second
system.time(validate_lesson(lsn))
system.time(validate_lesson(lsn))

## ----vl-tree, echo = FALSE, eval = getRversion() >= "4.0"---------------------
funs <- c(
  vl = "validate_lesson()",
  tl = "this_lesson()",
  sv = ".store$valid()",
  ggd = "gert::git_diff()",
  ggs = "gert::git_status()",
  ggl = "gert::git_log()",
  pl = "pegboard::Lesson$new()",
  ss = ".store$set()",
  sg = "set_globals()",
  srl = "set_resource_list()",
  res = ".resources$set()",
  grl = "get_resource_list()",
  im = "initialise_metadata()",
  sl = "set_language()",
  av = "add_varnish_translations()",
  tr = "tr_()",
  ts = "these$translations",
  gc = "get_config()",
  tm = "template_metadata()",
  tms = "this_metadata$set()",
  cs = "create_sidebar()",
  crd = "create_resources_dropdown()",
  lgs = "learner_globals$set()",
  igs = "instructor_globals$set()"
)
labels <- funs
to_lab <- c("ss", "res", "tms", "lgs", "igs", "ts")
labels[to_lab] <- cli::col_cyan(cli::style_bold(labels[to_lab]))
vltree <- data.frame(
  fn = funs,
  calls = I(list(
    vl = funs["tl"],
    tl = list(funs["sv"], funs["pl"], funs["ss"]),
    sv = list(funs["ggd"], funs["ggs"], funs["ggl"]),
    ggd = character(0),
    ggs = character(0),
    ggl = character(0),
    pl = character(0),
    ss = list(funs["sg"]),
    sg = list(funs["im"], funs["sl"], funs["srl"], funs["cs"], funs["crd"], funs["lgs"],
      funs["igs"]),
    srl = list(funs["grl"], funs["res"]),
    res = character(0),
    grl = list(funs["gc"]),
    im = list(funs["gc"], funs["tm"], funs["tms"]),
    sl = list(funs["av"]),
    av = list(funs["tr"]),
    tr = list(funs["ts"]),
    ts = character(0),
    gc = character(0),
    tm = character(0),
    tms = character(0),
    cs = character(0),
    crd = character(0),
    lgs = character(0),
    igs = character(0)
    )
  ),
  labels = labels
)
cli::tree(vltree)

## ----store-get----------------------------------------------------------------
snd <- asNamespace("sandpaper")
class(snd$.store)
print(snd$.store$get())

## ----store-valid--------------------------------------------------------------
snd$.store$valid(lsn)

## ----store-invald-------------------------------------------------------------
set_config(c(handout = TRUE), path = lsn, write = TRUE, create = TRUE)
snd$.store$valid(lsn)
snd$.store$set(lsn)
snd$.store$valid(lsn)

## ----metadata-----------------------------------------------------------------
snd <- asNamespace("sandpaper")
snd$this_metadata$get()

## ----fill-metadata------------------------------------------------------------
writeLines(snd$fill_metadata_template(snd$this_metadata))

## ----resources-get------------------------------------------------------------
snd <- asNamespace("sandpaper")
snd$.resources$get()

## ----globals------------------------------------------------------------------
snd <- asNamespace("sandpaper")
snd$instructor_globals$get()
snd$learner_globals$get()

## ----overview, results="asis", echo = FALSE, comment = ""---------------------
writeLines("```html")
writeLines(readLines(system.file("pkgdown/templates/content-overview.html",
      package = "varnish")))
writeLines("```")

## ----whisker------------------------------------------------------------------
snd <- asNamespace("sandpaper")
whisker::whisker.render("Edit this page: {{ translate.EditThisPage }}",
  data = snd$instructor_globals$get()
)

## ----set-language-es----------------------------------------------------------
snd <- asNamespace("sandpaper")
snd$set_config(c(lang = "es"), path = lsn, create = TRUE, write = TRUE)
snd$this_lesson(lsn)
whisker::whisker.render("Edit this page: {{ translate.EditThisPage }}",
  data = snd$instructor_globals$get()
)
Sys.getenv("LANGUAGE")

## ----set-language-en----------------------------------------------------------
snd$set_config(c(lang = "en"), path = lsn, create = TRUE, write = TRUE)
snd$this_lesson(lsn)
whisker::whisker.render("Edit this page: {{ translate.EditThisPage }}",
  data = snd$instructor_globals$get()
)

## ----translation-list, results = "asis", echo = FALSE-------------------------
snd <- asNamespace("sandpaper")
res <- glue::glue("| `translate.{names(tr)}` | `{sQuote(tr, q = 2)}` |", 
  tr = snd$tr_src("varnish"))
writeLines(c("| variable | string |\n| --- | --- |", res))

## ----translation-list-computed, results = "asis", echo = FALSE----------------
snd <- asNamespace("sandpaper")
res <- glue::glue("| `{names(tr)}` | `{sQuote(tr, q = 2)}` |", 
  tr = snd$tr_src("computed"))
writeLines(c("| variable | string |\n| --- | --- |", res))

## ----yaml, results="asis", echo = FALSE, comment = ""-------------------------
writeLines("```yaml")
writeLines(readLines(fs::path(lsn, "site", "_pkgdown.yaml")))
writeLines("```")

## ----pkgdown------------------------------------------------------------------
snd <- asNamespace("sandpaper")
pkg <- pkgdown::as_pkgdown(snd$path_site(lsn))
pkg[c("lang", "src_path", "dst_path", "meta")]

## ----data-template------------------------------------------------------------
dat <- pkgdown::data_template(pkg)
writeLines(yaml::as.yaml(dat[c("lang", "site", "yaml")]))

