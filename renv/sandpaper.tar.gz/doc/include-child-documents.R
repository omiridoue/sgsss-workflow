## ----setup, include = FALSE---------------------------------------------------
# comment to fix https://github.com/r-lib/pkgdown/issues/1843
knitr::opts_chunk$set(
    collapse = TRUE,
    compact = TRUE,
    comment = "#>"
)

# setup the lesson to include a child document
library("sandpaper")
library("pegboard")
snd <- asNamespace("sandpaper")
# do not use the package cache because it will slow us down
no_package_cache()
suppressMessages(lsn <- create_lesson(tempfile(), open = FALSE))

# Create the child file -----------------------------------------
txt <- c("## Session Information\n",
  "The following is the session information of this R session",
  "\n```{r sessioninfo}", "sessionInfo()", "```\n")
writeLines(txt, fs::path(lsn, "episodes", "files", "child.Rmd"))

# Append the episode --------------------------------------------
ep <- Episode$new(fs::path(lsn, "episodes", "introduction.Rmd"))
n <- length(xml2::xml_children(ep$body))
# we want to add the child just before the keypoints, which consist of the
# last three paragraphs
ep$add_md("```{r si, child = 'files/child.Rmd'}\n```\n", where = n - 3)
ep$write(fs::path(lsn, "episodes"), "Rmd")

# Load the lesson object ----------------------------------------
lsn_obj <- snd$this_lesson(lsn)

## ----first-tree, echo = FALSE, comment = "#"----------------------------------
withr::with_dir(lsn, fs::dir_tree("./episodes/"))

## ----echo-parent, echo = FALSE, results = 'asis'------------------------------
lsn_obj$episodes[[1]]$tail(15)

## ----echo-child, echo = FALSE, results = 'asis'-------------------------------
lsn_obj$children[[1]]$show()

## ----echo-built, echo = FALSE, results = 'asis'-------------------------------
snd$build_markdown(lsn, rebuild = FALSE, quiet = TRUE, slug = "introduction")
lsn_obj$load_built()
lsn_obj$built[[1]]$tail(47)

## ----add-writer, echo = FALSE, results = 'asis'-------------------------------
ep <- lsn_obj$episodes[[1]]
txt <- c(
  "```{r setup, echo = FALSE}",
  "writeLines(format(Sys.time()), 'data/time.txt')",
  "cat(paste0('The time is: ', readLines('data/time.txt')))",
  "```"
)
ep$add_md(txt, 1)
ep$write(fs::path(lsn, "episodes"), format = "Rmd")
ep$head(10)

## ----echo-episodes, echo = FALSE, comment = "#"-------------------------------
snd$build_markdown(lsn, rebuild = FALSE, quiet = TRUE)
withr::with_dir(lsn, fs::dir_tree("./episodes/"))

## ----echo-built-too, echo = FALSE, comment = "#"------------------------------
withr::with_dir(lsn, fs::dir_tree("./site/built/"))

## ----echo-time, echo = FALSE, results = 'asis'--------------------------------
lsn_obj$load_built()
lsn_obj$built[["site/built/introduction.md"]]$head(10)

## ----setup-new-child, echo = FALSE, comment = "#"-----------------------------
lsn_obj <- snd$this_lesson(lsn)
withr::with_dir(fs::path(lsn, "episodes", "files"), {
  fs::dir_create("children")
  fs::file_touch("../fig/one.png")
  writeLines(c(
      "---",
      "title: info",
      "---",
      "\nthis is a test file\n"
    ),
    con = "../../learners/info.md"
  )
  fs::file_move("child.Rmd", "children/child.Rmd")
})
# setup the child to use the correct code.
withr::with_dir(lsn, fs::dir_tree("./episodes/"))
ep <- lsn_obj$episodes[[1]]
code <- ep$code
xml2::xml_set_attr(code[[5]], "child",
  sQuote("files/children/child.Rmd", q = 2)
)
ep$write(fs::path(lsn, "episodes"), format = "Rmd")
lsn_obj <- snd$this_lesson(lsn)
lsn_obj$children[[1]]$add_md("
Here is a link to [the info document](../learners/info.md)

![example](fig/one.png){alt='example figure'}
")
lsn_obj$children[[1]]$write(fs::path(lsn, "episodes/files/children"),
  format = "Rmd"
)

## ----echo-parent-assets, echo = FALSE, results = 'asis'-----------------------
lsn_obj$episodes[[1]]$tail(15)

## ----echo-child-assets, echo = FALSE, results = 'asis'------------------------
lsn_obj$children[[1]]$show()

## ----show-built-assets, echo = FALSE, comment = "#"---------------------------
snd$build_markdown(lsn, rebuild = TRUE, quiet = TRUE)
withr::with_dir(lsn, fs::dir_tree("./site/built/"))

## ----echo-built-assets, echo = FALSE, results = 'asis'------------------------
lsn_obj$load_built()
lsn_obj$built[["site/built/introduction.md"]]$tail(50)

## ----warn-missing, echo = FALSE-----------------------------------------------
child <- lsn_obj$children[[1]]
prepend_dest <- function(nodes, new = "../../") {
  dst <- xml2::xml_attr(nodes, "destination")
  xml2::xml_set_attr(nodes, "destination", paste0(new, dst))
}
prepend_dest(child$links)
prepend_dest(child$images)
child$write(fs::path(lsn, "episodes/files/children"), format = "Rmd")
snd$clear_this_lesson()
validate_lesson(lsn)

