/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: IntAlterFunction.cpp
 *
 * Description: This file contains the implementation of the class
 * IntAlterFunction.
 *****************************************************************************/

#include "IntAlterFunction.h"

namespace siena
{
}
