/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: ThresholdLeftShapeEffect.h
 *
 * Description: This file contains the definition of the
 * ThresholdLeftShapeEffect class.
 *****************************************************************************/

#ifndef THRESHOLDLEFTSHAPEEFFECT_H_
#define THRESHOLDLEFTSHAPEEFFECT_H_

#include "BehaviorEffect.h"

namespace siena
{

    /**
     * Threshold shape effect having the statistic z_i >= par.
     */
    class ThresholdLeftShapeEffect : public BehaviorEffect
    {
    public:
        ThresholdLeftShapeEffect(const EffectInfo *pEffectInfo, bool lower);

        virtual double calculateChangeContribution(int actor,
                                                   int difference);
        virtual double egoStatistic(int ego, double *currentValues);

    private:
        // lpar is the internal effect parameter
        int lpar{};
        bool llower {};

    };

}

#endif /*THRESHOLDLEFSHAPEEFFECT_H_*/
