/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: CovariateEgoAlterEffect.cpp
 *
 * Description: This file contains the implementation of the
 * CovariateEgoAlterEffect class.
 *****************************************************************************/
#include "CovariateEgoMaxAlterEffect.h"
#include "network/Network.h"
#include "network/IncidentTieIterator.h"
#include "network/CommonNeighborIterator.h"
#include "model/variables/NetworkVariable.h"

namespace siena
{

	/**
	 * Constructor.
	 * @param[in] pEffectInfo the effect descriptor
	 * @param[in] reciprocal indicates if only reciprocal ties have to be
	 * considered
	 */
	CovariateEgoMaxAlterEffect::CovariateEgoMaxAlterEffect(
		const EffectInfo *pEffectInfo,
		bool reciprocal, bool maximum) : CovariateDependentNetworkEffect(pEffectInfo)
	{
		this->lreciprocal = reciprocal;
		this->lmaximum = maximum;
	}

	/**
	 * Calculates the contribution of a tie flip to the given actor.
	 */
	double CovariateEgoMaxAlterEffect::calculateContribution(int alter) const
	{
		double change = 0;
		double altervalue = this->value(alter);
		if ((this->lmaximum) && (this->value(this->ego()) > altervalue))
		{
			altervalue =  this->value(this->ego());
		}

		if (!this->lreciprocal || this->inTieExists(alter))
		{
			change = this->value(this->ego()) * altervalue;
		}

		return change;
	}

	/**
	 * The contribution of the tie from the implicit ego to the given alter
	 * to the statistic. It is assumed that preprocessEgo(ego) has been
	 * called before.
	 */
	double CovariateEgoMaxAlterEffect::tieStatistic(int alter)
	{
		double statistic = 0;
		double altervalue = this->value(alter);

		if ((this->lmaximum) && (this->value(this->ego()) > altervalue))
		{
			altervalue =  this->value(this->ego());
		}

		if (!this->missing(this->ego()) && !this->missing(alter) &&
			(!this->lreciprocal || this->inTieExists(alter)))
		{
			statistic = this->value(this->ego()) * altervalue;
		}

		return statistic;
	}

}
