/******************************************************************************
 * SIENA: Simulation Investigation for Empirical Network Analysis
 *
 * Web: http://www.stats.ox.ac.uk/~snijders/siena/
 *
 * File: CovariateEgoMaxAlterEffect.h
 *
 * Description: This file contains the definition of the
 * CovariateEgoMaxAlterEffect class.
 *****************************************************************************/

#ifndef COVARIATEEGOMAXALTEREFFECT_H_
#define COVARIATEEGOMAXALTEREFFECT_H_

#include "CovariateDependentNetworkEffect.h"

namespace siena
{

	/**
	 * Covariate-ego x alter effect and covariate-ego x alter x reciprocity
	 * effect (see manual).
	 */
	class CovariateEgoMaxAlterEffect : public CovariateDependentNetworkEffect
	{
	public:
		CovariateEgoMaxAlterEffect(const EffectInfo *pEffectInfo, bool reciprocal, bool maximum);

		virtual double calculateContribution(int alter) const;

	protected:
		virtual double tieStatistic(int alter);

	private:
		// Indicates if the reciprocal version of the effect is required
		bool lreciprocal{};
		// Indicates if the maximum version of the effect is required
		bool lmaximum {};
	};

}

#endif /*COVARIATEEGOMAXALTEREFFECT_H_*/
